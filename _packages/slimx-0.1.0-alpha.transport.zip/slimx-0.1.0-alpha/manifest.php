<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'f6efa81c449ff3bc00c3506b4619cbe9',
      'native_key' => 'slimx',
      'filename' => 'modNamespace/48dacc65dec9d2a5d07c1400afbb57df.vehicle',
      'namespace' => 'slimx',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '0cba80a6524f73bb897e7a3806b4c0d5',
      'native_key' => NULL,
      'filename' => 'modCategory/ffbc199518941073d83ba0aeb1d612f8.vehicle',
      'namespace' => 'slimx',
    ),
  ),
);