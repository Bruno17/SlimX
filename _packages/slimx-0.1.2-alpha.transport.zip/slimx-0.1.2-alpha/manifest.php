<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'c36e8aedeb13aa334873b775ce7f4c0b',
      'native_key' => 'slimx',
      'filename' => 'modNamespace/74f71e094368f6df8dfd64582f9e294f.vehicle',
      'namespace' => 'slimx',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'f8fb48f941578fd51b8d6113c5f6bf18',
      'native_key' => NULL,
      'filename' => 'modCategory/84726ab1d44c531bf09e303804a2c849.vehicle',
      'namespace' => 'slimx',
    ),
  ),
);